function [X, y] = load_dataset(path)
  %incarcam in memorie fisierul .mat
  load(path);
endfunction
