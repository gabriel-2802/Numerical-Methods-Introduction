function [InitialMatrix, Y] = parse_csv_file(file_path)
    data = csvread(file_path)
    %later
endfunction
